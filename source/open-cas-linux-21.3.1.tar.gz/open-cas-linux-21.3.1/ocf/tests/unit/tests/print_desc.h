/*
 * Copyright(c) 2012-2021 Intel Corporation
 * SPDX-License-Identifier: BSD-3-Clause-Clear
 */

#define print_test_description(description) print_message("[   DESC   ] %s\n", description);
