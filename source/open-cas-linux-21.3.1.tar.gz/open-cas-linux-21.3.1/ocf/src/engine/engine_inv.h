/*
 * Copyright(c) 2012-2021 Intel Corporation
 * SPDX-License-Identifier: BSD-3-Clause-Clear
 */

#ifndef ENGINE_INV_H_
#define ENGINE_INV_H_

void ocf_engine_invalidate(struct ocf_request *req);

#endif /* ENGINE_INV_H_ */
