/*
 * Copyright(c) 2012-2021 Intel Corporation
 * SPDX-License-Identifier: BSD-3-Clause-Clear
 */

#ifndef __CACHE_ENGINE_OPS_H_
#define __CACHE_ENGINE_OPS_H_

int ocf_engine_ops(struct ocf_request *req);

#endif /* __CACHE_ENGINE_OPS_H_ */
