/*
 * Copyright(c) 2012-2021 Intel Corporation
 * SPDX-License-Identifier: BSD-3-Clause-Clear
 */

#ifndef ENGINE_2DC_H_
#define ENGINE_2DC_H_

int ocf_io_d2c(struct ocf_request *req);

#endif /* ENGINE_2DC_H_ */
