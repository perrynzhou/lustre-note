/*
 * Copyright(c) 2012-2021 Intel Corporation
 * SPDX-License-Identifier: BSD-3-Clause-Clear
 */

#ifndef ENGINE_ZERO_H_
#define ENGINE_ZERO_H_

void ocf_engine_zero_line(struct ocf_request *req);

#endif /* ENGINE_ZERO_H_ */
