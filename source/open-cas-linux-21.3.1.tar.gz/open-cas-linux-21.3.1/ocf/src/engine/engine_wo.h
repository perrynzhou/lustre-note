/*
 * Copyright(c) 2019-2021 Intel Corporation
 * SPDX-License-Identifier: BSD-3-Clause-Clear
 */

#ifndef ENGINE_WO_H_
#define ENGINE_WO_H_

int ocf_read_wo(struct ocf_request *req);

#endif /* ENGINE_WO_H_ */
