/*
 * Copyright(c) 2012-2021 Intel Corporation
 * SPDX-License-Identifier: BSD-3-Clause-Clear
 */

#ifndef __ENGINE_DISCARD_H__
#define __ENGINE_DISCARD_H__

int ocf_discard(struct ocf_request *req);

#endif
