/*
 * Copyright(c) 2012-2021 Intel Corporation
 * SPDX-License-Identifier: BSD-3-Clause-Clear
 */

#ifndef __METADATA_COMMON_H__
#define __METADATA_COMMON_H__

typedef void (*ocf_metadata_end_t)(void *priv, int error);

#endif /* __METADATA_COMMON_H__ */

