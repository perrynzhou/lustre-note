/*
 * Copyright(c) 2012-2021 Intel Corporation
 * SPDX-License-Identifier: BSD-3-Clause-Clear
 */
#ifndef __LAYER_CLEANING_POLICY_NOP_STRUCTS_H__

#define __LAYER_CLEANING_POLICY_NOP_STRUCTS_H__

struct nop_cleaning_policy_meta {
} __attribute__((packed));

struct nop_cleaning_policy {
};

#endif
