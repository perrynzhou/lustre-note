/*
 * Copyright(c) 2019-2021 Intel Corporation
 * SPDX-License-Identifier: BSD-3-Clause-Clear
 */

#ifndef __DATA_H__
#define __DATA_H__

struct volume_data {
	void *ptr;
	int offset;
};

#endif
