#ifndef _SUSTAINED_INODES_H_
#define _SUSTAINED_INODES_H_

void sinodes_term(void);
void sinodes_init(const char *mountpoint);

#endif
