#ifndef _GLUE_H_
#define _GLUE_H_

#define GLUE_HELPER(X,Y) X##Y
#define GLUE(X,Y) GLUE_HELPER(X,Y)

#endif
