#!/bin/sh

aclocal
autoconf
automake --foreign
